﻿import AppKit

@IBObject
public class MainWindowController : NSWindowController {

	init() {

		super.init(windowNibName: "MainWindowController")

		// Custom initialization
	}

	var textLabel: NSTextField!

	public override func windowDidLoad() {

		super.windowDidLoad()

		super.windowDidLoad()

		// Create and configure the text label
		textLabel = NSTextField(with: "My App")
		textLabel.alignment = .center


		// Add the label to the window's content view
		window?.contentView?.addSubview(textLabel)

		// Center the label in the window
		textLabel.translatesAutoresizingMaskIntoConstraints = false
		NSLayoutConstraint.activateConstraints([
			textLabel.centerXAnchor.constraint(equalTo: window!.contentView!.centerXAnchor),
			textLabel.centerYAnchor.constraint(equalTo: window!.contentView!.centerYAnchor),
			textLabel.widthAnchor.constraint(equalToConstant: 200),
			textLabel.heightAnchor.constraint(equalToConstant: 24)
		])
	}
}